var bar = require("bar");  //在引用一个文件夹

console.log(bar.msg);
