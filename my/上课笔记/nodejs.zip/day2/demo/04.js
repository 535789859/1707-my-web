var foo = require("./test/foo.js");

console.log(foo.msg);
console.log(foo.info);
foo.showInfo();