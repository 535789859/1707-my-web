var foo = require("foo.js");  //没有写./

console.log(foo.msg);