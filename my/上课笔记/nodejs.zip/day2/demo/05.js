
var People = require("./test/People.js");
var xiaoming = new People("小明","男","12");
xiaoming.sayHello();